# Primero, asegúrate de reiniciar R
## Esto lo conseguimos con Session > Restart R y clickeando en la escoba del 
## panel de "Environment" (superior derecho).


# Luego, corre las siguientes líneas (ctrl+enter) para iniciar el tutorial

library(learnr)
rmarkdown::run("interactivo-manejo/interactivo-manejo.Rmd")
