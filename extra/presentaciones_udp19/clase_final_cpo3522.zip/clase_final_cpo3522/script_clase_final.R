install.packages("tidyverse") # esto solo deben hacerlo una vez por computador
library(tidyverse)

# Crear una base de ejemplos y guardarla en el disco:

base_ejemplo <- midwest %>% 
  select(popdensity, percblack)

write_csv(x = base_ejemplo, path = "datos/base_ejemplo.csv") # csv, Excel lo lee
write_rds(x = base_ejemplo, path = "datos/base_ejemplo.rds") # formato de R, nunca falla


# Guardar gráficos de ggplot2 desde R: 

grafico_ejemplo <- ggplot(data = base_ejemplo, mapping = aes(x = popdensity, percblack)) +
  geom_point()
grafico_ejemplo

ggsave(plot = grafico_ejemplo, filename = "grafico_ejemplo.png", 
       width = 14, height = 10, units = "cm")
# Cambiar el tamaño nos permite tener control sobre las escalas.
## Esto último suele ser ensayo y error.
# Un tutorial al respecto: http://stat545.com/block017_write-figure-to-file.html