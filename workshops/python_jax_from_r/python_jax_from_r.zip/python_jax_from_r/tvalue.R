tval_jax_source <- function(x, y, IM){
  n <- IM$shape[[1]]
  g <- IM$shape[[2]]
  
  # demean variables
  x <- x - jnp$mean(x)
  y <- y - jnp$mean(y)
  
  # get coefficient
  num <- x %*% y
  den <- x$T %*% x
  coef <- num / den
  
  # get residuals
  r <- y - coef * x
  
  # get cluster meat
  XE <- x * r
  XE_sum <- IM$T %*% XE
  M = XE_sum$T %*% XE_sum
  
  # get bread
  bread = 1 / den
  
  # get variance-covariance matrix (w/ par and group corrections)
  V = (n - 1) / (n - 2) * g / (g - 1) * bread * M * bread
  
  # return t-value
  return(coef / jnp$sqrt(V))
}