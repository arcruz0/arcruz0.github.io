# Load reticulate and declare Python packages
library(reticulate)
py_require(c("jax", "jaxopt"))

# Import them as R objects
jax <- import("jax")
jnp <- import("jax.numpy")
jaxopt <- import("jaxopt")

# Automatic differentiation: simple example ------------------------------------

# Define f(x)=x^2:
f <- \(x) x^2
f(-3.3); f(5)

# get gradient using JAX (analytically, we know f'(x)=2x)
f_grad <- jax$grad(f)
f_grad(-3.3); f_grad(5)



# Define g(x)=sin(x):
g <- \(x) jnp$sin(x)
g(-3.3); g(5)

# get gradient using JAX (analytically, we know g'(x)=sin(x))
g_grad <- jax$grad(g)
g_grad(-3.3); g_grad(5)



# Function with an if/else statement:
h <- \(x) jnp$where(x > 0, f(x), g(x))
h(-3.3); h(5)
# get gradient. JAX figures it out through the loop 🤯 
h_grad <- jax$grad(h)
h_grad(-3.3); h_grad(5)



# Note: reticulate does not convert JAX arrays into R 
value <- h_grad(-3.3)
value
class(value)

# it is common for us to have to do R->JAX and JAX->R conversions ourselves
j2r <- \(x) np$array(x)
r2j <- \(x) jnp$array(x)
h_grad(-3.3) |> j2r()


# A sensitivity bound for error propagation ------------------------------------

# Load V-Dem cross-sectional data and estimate model:

vd <- read.csv("vdem_2019.csv")
head(vd)

library(fixest)
m <- feols(l_e_gdppc ~ v2x_polyarchy, vd, vcov = ~region)
m

# Create a function that takes an arbitrary vector and uses it as indep. var.:
tval_r <- \(x){
  vd_cs$v2x_polyarchy_opt <- x
  m_cs <- feols(l_e_gdppc ~ v2x_polyarchy_opt, vd_cs, vcov = ~region)
  m_cs$coeftable[2,3]
}
tval_r(vd_cs$v2x_polyarchy)
tval_r(vd_cs$v2x_polyarchy_codelow)  # all data points to the left
tval_r(vd_cs$v2x_polyarchy_codehigh) # all data points to the right

# What's the maximum amount of damage we can do to the t-value?

# we can optimize with R's optim() (finite diff - takes ~3 minutes in my laptop)
optim(par = vd$v2x_polyarchy, 
      fn = tval_r, 
      method = "L-BFGS-B", 
      lower = vd$v2x_polyarchy_codelow, upper = vd$v2x_polyarchy_codehigh)

# Use JAX instead?

# Load JAX function to calculate t-value from x, y, and IM (indicator matrix)
source("tvalue.R")
IM <- model.matrix(~region - 1, data = vd)
tval_jax <- \(x) tval_jax_source(r2j(x), y = r2j(vd_cs$l_e_gdppc), IM = r2j(IM))

tval_jax(x = r2j(vd_cs$v2x_polyarchy))
tval_jax(x = r2j(vd_cs$v2x_polyarchy_codelow))
tval_jax(x = r2j(vd_cs$v2x_polyarchy_codehigh))

# Automatic differentiation for this function
tval_jax_grad <- jax$grad(tval_jax)

# And then provide both function and gradient to optim() 
o <- optim(par = vd_cs$v2x_polyarchy, 
           fn = \(x) j2r(tval_jax(x)),
           gr = \(x) j2r(tval_jax_grad(x)),
           method = "L-BFGS-B", 
           lower = vd_cs$v2x_polyarchy_codelow, upper = vd_cs$v2x_polyarchy_codehigh)
o

# Here's how we moved the points:

library(ggplot2)

ggplot(cbind(vd_cs, v2x_polyarchy_opt = o$par), 
       aes(x = v2x_polyarchy_opt, y = l_e_gdppc,
           xmin = v2x_polyarchy_codelow, xmax = v2x_polyarchy_codehigh)) +
  geom_point() +
  geom_linerange()
