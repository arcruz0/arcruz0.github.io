# Data prep --------------------------------------------------------------------

# load some sentences from the Universal Declaration of Human Rights:
vector_articles <- c(
  "EN-1"  = "All human beings are born free and equal in dignity and rights",
  "PT-1"  = "Todos os seres humanos nascem livres e iguais em dignidade e em direitos",
  "DE-1"  = "Alle Menschen sind frei und gleich an Würde und Rechten geboren",
  "CN-1"  = "人人生而自由,在尊严和权利上一律平等",
  "EN-17" = "Everyone has the right to own property alone as well as in association with others."
)



# Compute embeddings (in-and-out Python) ---------------------------------------

# load reticulate
library(reticulate)

# declare the Python packages we will use, and import them as R objects
py_require("sentence_transformers")
sentence_transformers <- import("sentence_transformers")

# do our Python thing! load the model and compute sentence-level embeddings: 
model <- sentence_transformers$SentenceTransformer("intfloat/multilingual-e5-base")
embeddings <- model$encode(vector_articles, normalize_embeddings = T)



# Analyze ----------------------------------------------------------------------

# "embeddings" is just an R matrix
class(embeddings)
dim(embeddings)

rownames(embeddings) <- names(vector_articles)

# compute cosine similarity ("semantic similarity")
embeddings %*% t(embeddings) 
