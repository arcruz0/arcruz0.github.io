library(tidyverse)
library(summarytools)

base_midwest <- read_csv("datos/midwest.csv")

view(dfSummary(base_midwest), file = "11f_reporte_summarytools.html")