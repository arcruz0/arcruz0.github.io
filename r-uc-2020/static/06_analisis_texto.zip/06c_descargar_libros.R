# Cargar paquetes ----

library(tidyverse)

# install.packages("tidytext")
library(tidytext)
library(stopwords)  # se instala solo con tidytext

# install.packages("gutenbergr")
library(gutenbergr) # descargar libros de dominio público desde Project Gutenberg 



# Leviathan ----

leviathan <- gutenberg_download(3207, strip = T) 

leviathan2 <- leviathan %>% 
  # eliminar las lineas sin info (espacios o separadores)
  filter(!str_detect(text, "^[\\s[:punct:]]*$")) %>% 
  # generar variable con capítulos
  mutate(chapter = cumsum(str_detect(text, "(CHAPTER )")),
         line    = 1:nrow(.)) %>% 
  # incluir información sobre el libro
  mutate(author = "Thomas Hobbes",
         book   = "Leviathan") %>% 
  # reordenar columnas
  select(author, book, gutenberg_id, chapter, line, text)

write_csv(leviathan2, "datos/leviathan.csv")



# On Liberty ----

on_liberty <- gutenberg_download(34901, strip = T)

on_liberty2 <- on_liberty %>% 
  # eliminar las lineas sin info (espacios o separadores)
  filter(!str_detect(text, "^[\\s[:punct:]]*$")) %>% 
  # generar variable con caps. (es imposible no contar las del índice usando expr. regulares, por eso las arreglo ex post)
  mutate(text = str_remove_all(text, "(<i>)|(</i>)"),
         chapter = cumsum(str_detect(text, "(CHAPTER )")),
         line    = 1:nrow(.)) %>% 
  mutate(chapter = chapter - 5) %>% 
  mutate(chapter = if_else(chapter < 0, 0, chapter)) %>% 
  # incluir información sobre el libro
  mutate(author = "John Stuart Mill",
         book   = "On Liberty") %>% 
  # reordenar columnas
  select(author, book, gutenberg_id, chapter, line, text)

write_csv(on_liberty2, "datos/on_liberty.csv")



# A Vindication of the Rights of Women ----

rights_of_women <- gutenberg_download(3420, strip = T)

rights_of_women2 <- rights_of_women %>% 
  # eliminar las lineas sin info (espacios o separadores)
  filter(!str_detect(text, "^[\\s[:punct:]]*$")) %>% 
  # generar variable con caps. (es muy difícil no contar las del índice usando expr. regulares, por eso las arreglo ex post)
  mutate(text = str_remove_all(text, "(<i>)|(</i>)"),
         chapter = cumsum(str_detect(text, "(CHAPTER )")),
         line    = 1:nrow(.)) %>% 
  mutate(chapter = chapter - 13) %>% 
  mutate(chapter = if_else(chapter < 0, 0, chapter)) %>%
  # incluir información sobre el libro
  mutate(author = "Mary Wollstonecraft",
         book   = "A Vindication of the Rights of Woman") %>% 
  # reordenar columnas
  select(author, book, gutenberg_id, chapter, line, text)

write_csv(rights_of_women2, "datos/rights_of_women.csv")

