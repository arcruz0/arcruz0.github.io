# Brevemente, este es un script "tradicional" de R, sin R Markdown.
# La extensión es .R.

# Nota que aquí los comentarios van con # inicial, pues se asume que todo el resto es código.

# Podemos hacer exactamente lo mismo que en el formato de R Markdown, con (al menos)
## dos diferencias. Primero, el código se correrá en la consola, no inmediatamente después
## de cada comando. Segundo, no se puede compilar esto a un documento.

3 + 3

library(tidyverse)

df_trump_scores <- read_csv("datos/trump_scores_202003_cong116.csv")

mean(df_trump_scores$trump_score)
median(df_trump_scores$trump_score)

# De todas formas, los scripts .R son útiles para cosas rápidas y mucha gente los ocupa.
# En el curso ocuparemos mayoritariamente scripts .Rmd.