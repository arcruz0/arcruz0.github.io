# Corre las siguientes líneas (ctrl+enter) para iniciar el tutorial
library(learnr)
rmarkdown::run("interactivo-manejo/interactivo-manejo.Rmd")